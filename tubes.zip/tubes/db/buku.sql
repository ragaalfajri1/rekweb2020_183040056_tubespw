-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 17 Apr 2019 pada 14.58
-- Versi server: 10.1.36-MariaDB
-- Versi PHP: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `buku`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE `buku` (
  `JudulBuku` varchar(90) NOT NULL,
  `Pengarang` varchar(90) NOT NULL,
  `Penerbit` varchar(90) NOT NULL,
  `TahunTerbit` int(4) NOT NULL,
  `Harga` varchar(30) NOT NULL,
  `Gambar` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `buku`
--

INSERT INTO `buku` (`JudulBuku`, `Pengarang`, `Penerbit`, `TahunTerbit`, `Harga`, `Gambar`) VALUES
('Laskar Pelangi', 'Andrea Hirata', 'Bentang Pustaka', 2005, '75000', 'laskarpelangi.jpg'),
('Manusia Kamar', 'Seno Gumira Ajidarma', 'CV Haji Masagung', 1988, '25000', 'manusiakamar.jpg'),
('Robin Hood', 'Paul Creswick', 'Elex Media Komputindo', 2009, '30000', 'robin.jpg'),
('Memahami Film', 'Himawan Pratists', 'Homerian Pustaka', 2008, '45000', 'memahamifilm.jpg'),
('God,Do You Speak English?', 'Jeff Kristianto,Nina Silvia,Rini hanifa', 'Rene Books', 2013, '40000', 'goddoyou.jpg'),
('Pudarnya Pesona Cleopatra', 'Habiburrahman El Shirazy', 'Republik Jakarta', 2005, '30000', 'cleopatra.jpg'),
('Koala Kumal', 'RadityaDika', 'Gagas Media', 2015, '67000', 'koalakumal.jpg'),
('5 Cm', 'Dhonny Dhirgantoro', 'PT Grasindo Yogyakarta', 2005, '65000', '5cm.jpg'),
('Perahu Kertas', 'Dewi Lestari', 'Treudee Pustaka Sejati & Bentang Pustaka', 2010, '125000', 'perahukertas.jpg'),
('Sepatu Dahlan', 'Khrisna Pabichara', 'Noura Books', 2012, '50000', 'dahlan.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
