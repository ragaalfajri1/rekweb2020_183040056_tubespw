<?php 	
require 'functions.php';
session_start();

if(isset($_COOKIE['id']) && isset($_COOKIE['key']) ){
	$id = $_COOKIE['id'];
	$key = $_COOKIE['key'];

	$result = mysqli_query($conn,"SELECT username FROM user WHERE id = $id ");
	$row = mysqli_fetch_assoc($result);

	if($key === hash('sha256',$row['username']) ){
		$_SESSION['login'] = true;
	}
	
}


if(isset($_SESSION['username']) ){
	header("Location: index.php");
	exit;
}


if(isset($_POST['login']) ){
		$username = $_POST['username'];
		$password = $_POST['password'];

		$result = mysqli_query($conn,"SELECT * FROM user WHERE username = '$username' ");

		// cek username
		if(mysqli_num_rows($result) === 1 ) {

			//cek password
			$row = mysqli_fetch_assoc($result);
			if(password_verify($password,$row["password"]) ){
				$_SESSION['username'] = $username;

				// cek remember
				if (isset($_POST['remember']) ) {

					setcookie('id',$row['id'],time()+60);
					setcookie('key',hash('sha256',$row['username']),time()+60);

				}


				header("Location: index.php");
				exit;
			} 
		$error = true;
	}


		// LOGIN MANUAL
		/*if($username == 'ragaalfajri' && $password == '1234'){
				// berhasil login
		   $_SESSION['username'] = $username;
		   header("Location: index.php");
		   exit;
		}else {
			// gagal login
			$error = 'UserName / Password Salah ! Jangan coba Memaksa Masuk !!!';
		}*/
}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<style>
		.login{
			text-align: center;
			margin-right: 100px;

		}
		h1{
			text-align: center;
			margin-top: 150px;
			margin-left: -60px;
			font-family: sans-serif;
		}
		img {
			width: 280px;
			height: 150px;
			margin-right: -38px;
		}
		p {
			margin-right: -50px;
		}
		.daftar{
			margin-right: 5px;
		}
	</style>
</head>
<body>
		
<h1>Login</h1>
<div class="login">
<form method="post" action="" class="form">
<?php  if(isset($error) ) : ?>
	<p style="color:red; font-style:italic;">UserName / Password Salah ! Jangan coba Memaksa Masuk !!!</p>
<?php endif; ?>
	<img src="assets/img/logo.jpg">
	<ul>	
			<label>Username :</label><br>	
			<input type="text" name="username" id="username">
		<br>
			<label>Password :</label><br>	
			<input type="password" name="password" id="password">
		<br>
			<input type="checkbox" name="remember" id="remember">
			<label>Remember me</label><br>
		<br>
		    <button type="submit" name="login">Login</button>
		<br><br>
		<button class="daftar"><a href="registrasi.php">Daftar</a></button>
	</ul>
</form>
</div>
</body>	
</html>