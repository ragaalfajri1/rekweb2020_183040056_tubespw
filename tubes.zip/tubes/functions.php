<?php 	
$conn = mysqli_connect('localhost', 'root', '', 'buku');

function query($query){
	global $conn;
	$result = mysqli_query($conn, $query);

	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;
	}
	return $rows;
}

function tambah($data){
	global $conn;
	$JudulBuku = htmlspecialchars($data['JudulBuku']);
	$Pengarang = htmlspecialchars($data['Pengarang']);
	$Penerbit = htmlspecialchars($data['Penerbit']);
	$TahunTerbit = htmlspecialchars($data['TahunTerbit']);
	$Harga = htmlspecialchars($data['Harga']);
	
	//upload gambar
	$Gambar = upload();
	if(!$Gambar){
 
		return false;
	}
	

	$query = "INSERT INTO buku 
			VALUES
			('', '$JudulBuku', '$Pengarang', '$Penerbit', '$TahunTerbit', '$Harga', '$Gambar')";
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

function upload(){

	$namaFile = $_FILES['Gambar']['name'];
	$ukuranFile = $_FILES['Gambar']['size'];
	$error = $_FILES['Gambar']['error'];
	$tmpName = $_FILES['Gambar']['tmp_name'];

	// cek apakah tidak ada gambar yang di upload
	if($error === 4){
		echo "<script>
				alert ('Pilih Gambar Terlebih Dahulu !!!')
			  </script>";
		return false;
	}

	// cek yang diupload adalah gambar
	$ektensiGambarValid = ['jpg','jpeg','png'];
	$ektensiGambar = explode('.',$namaFile);
	$ektensiGambar = strtolower(end($ektensiGambar) );
	if(!in_array($ektensiGambar,$ektensiGambarValid) ){
			echo "<script>
				alert ('Anda Mengupload Bukan Gambar!!!')
			  </script>";
		return false;

	}

	//cek untuk gambar terlalu besar
	if($ukuranFile > 1000000){
		echo "<script>
				alert ('Ukuran Gambar Terlalu Besar!')
			  </script>";
		return false;

	}

	$namaFileBaru = uniqid();
	$namaFileBaru .= '.';
	$namaFileBaru .= $ektensiGambar;

	// gambar diupload
	move_uploaded_file($tmpName,'assets/img/'.$namaFileBaru);
 
	return $namaFileBaru;

}

function hapus($id){
	global $conn;
	mysqli_query($conn, "DELETE FROM buku WHERE id = $id");

	return mysqli_affected_rows($conn);
}

 function ubah($data){
	global $conn;
	$id = $data['id'];
	$JudulBuku = htmlspecialchars($data['JudulBuku']);
	$Pengarang = htmlspecialchars($data['Pengarang']);
	$Penerbit = htmlspecialchars($data['Penerbit']);
	$TahunTerbit = htmlspecialchars($data['TahunTerbit']);
	$Harga = htmlspecialchars($data['Harga']);
	$gambarLama = htmlspecialchars($data['gambarLama']);
	// cek apakah user pilih gambar atau tidak
	if ($_FILES['Gambar']['error'] === 4 ){
		$Gambar = $gambarLama;
	} else {
		$Gambar = upload();
	}

	$query = "UPDATE buku 
				SET
				JudulBuku = '$JudulBuku',
				Pengarang = '$Pengarang',
				Penerbit = '$Penerbit',
				TahunTerbit = '$TahunTerbit',
				Harga = '$Harga',
				Gambar = '$Gambar'

			WHERE id = $id
				";
		
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

function registrasi($data){
	global $conn;

	$username = strtolower(stripslashes($data["username"]) );
	$password = mysqli_real_escape_string($conn,$data["password"]);
	$password2 = mysqli_real_escape_string($conn,$data["password2"]);

	//cek username sudah ada atau belum ada
	$result = mysqli_query($conn,"SELECT username FROM user WHERE username = '$username' ");

	if(mysqli_fetch_assoc($result) ){
		echo "<script>
				alert('Username sudah terdaftar !');
			  </script>";
		return false;
	}

	//cek konfir password
	if($password !== $password2){
		echo "<script>
				alert('Konfirmasi Password Tidak Sesuai !!!');
			  </script>";
			  return false;
	}

	//enkripsi password
	$password = password_hash($password,PASSWORD_DEFAULT);

	// tambahkan userbaru ke databases
	mysqli_query($conn,"INSERT INTO user VALUES('','$username','$password')");

	return mysqli_affected_rows($conn);
}

 ?>