<?php 
session_start();
if(!isset($_SESSION['username']) ){
	header("Location: login.php");
	exit;
}

require 'functions.php';

$id = $_GET['id'];
$bku = query("SELECT * FROM buku WHERE id = $id")[0];

if (isset($_POST['ubah'])){
	if (ubah($_POST) > 0) {
		echo "<script>
				alert('data berhasil diubah!');
				document.location.href = 'index.php';
				</script>";
	}

}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Form Ubah Data Buku</title>
</head>
<body>
	<h3>Form Ubah Data Buku</h3>
	<form method="post" action="" enctype="multipart/form-data">
		<input type="hidden" name="id" value="<?= $bku['id']; ?>">
		<input type="hidden" name="gambarLama" value="<?= $bku['Gambar']; ?>">
		<ul>
			<li>
				Masukkan Gambar :  <br>
				<img src="assets/img/<?= $bku['Gambar']; ?>" width="70"><br>
				<input type="file" name="Gambar">
			</li>
			<li>
				Judul Buku :  <br>
				<input type="text" name="JudulBuku" required value="<?= $bku['JudulBuku']; ?>">
			</li>
			<li>
				Pengarang :  <br>
				<input type="text" name="Pengarang" required value="<?= $bku['Pengarang']; ?>">
			</li>
			<li>
				Penerbit :  <br>
				<input type="text" name="Penerbit" required value="<?= $bku['Penerbit']; ?>"> <br>
			</li>
			<li>
				TahunTerbit :  <br>
				<input type="text" name="TahunTerbit" required value="<?= $bku['TahunTerbit']; ?>"> <br>
			</li>
			<li>
				Harga :  <br>
				<input type="text" name="Harga" required value="<?= $bku['Harga']; ?>"> <br>
			</li>
			<li>
				<button type="submit" name="ubah">Ubah Data!</button>
			</li>
		</ul>
	</form>
</body>
</html>