<?php 
session_start();
if(!isset($_SESSION['username']) ){
	header("Location: login.php");
	exit;
}

require 'functions.php';

$buku = query("SELECT * FROM buku");

if(isset($_GET['cari']) ){

	$keyword = $_GET['keyword'];
	$query_cari = "SELECT * FROM buku WHERE
				    JudulBuku LIKE '%$keyword%' OR 
				    Pengarang LIKE '%$keyword%' OR
				    Penerbit LIKE '%$keyword%' OR
				    TahunTerbit LIKE '%$keyword%' OR
				    Harga LIKE '%$keyword%'


					";
	$buku = query($query_cari);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<button><a href="logout.php">Logout</a></button>

	<title>Data Buku</title>
</head>
<body>
	<h3>Daftar Buku</h3>

	<a href="tambah.php">Tambah Data Buku</a>
		<br><br>

			<form action="" method="get">	
				<input type="text" name="keyword" autofocus placeholder="Masukan keyword" autocomplete="off">
				<button type="submit" name="cari">Cari !</button>
				<button><a href="index.php">Tampilkan Semua</a></button>

			</form>

			<br>	

		<table border="1" cellpadding="10" cellspacing="0">
		<tr>
			<th>No.</th>
			<th>Aksi</th>
			<th>Gambar</th>
			<th>JudulBuku</th>
			<th>Pengarang</th>
			<th>Penerbit</th>
			<th>TahunTerbit</th>
			<th>Harga</th>
		</tr>

		<?php if( empty($buku) ) : ?>
				<tr>	
					<td colspan="6">Data tidak ditemukan</td>
				</tr>
		<?php endif; ?>

		<?php 
		$i = 1;
		foreach ($buku as $bku) : 
		?>
		<tr>
			<td><?= $i++; ?></td>
			<td>
				<a href="ubah.php?id=<?= $bku['id']; ?>">ubah</a> | 
				<a href="hapus.php?id=<?= $bku['id']; ?>" onclick="return confirm('yakin anda ingin menghapusnya?');">hapus</a>
			</td>
			<td><img src="assets/img/<?= $bku["Gambar"] ?>" width="50"></td>
			<td><?= $bku['JudulBuku']; ?></td>
			<td><?= $bku['Pengarang']; ?></td>
			<td><?= $bku['Penerbit']; ?></td>
			<td><?= $bku['TahunTerbit']; ?></td>
			<td><?= $bku['Harga']; ?></td>
		</tr>
	<?php endforeach; ?>
	</table>
</body>
</html>