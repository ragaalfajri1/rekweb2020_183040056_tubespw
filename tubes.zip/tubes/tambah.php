<?php  
session_start();
if(!isset($_SESSION['username']) ){
	header("Location: login.php");
	exit;
}

require 'functions.php';

if (isset($_POST['tambah'])){
	if (tambah($_POST) > 0) {
		echo "<script>
				alert('data berhasil ditambahkan!');
				document.location.href = 'index.php';
				</script>";
	}

}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Form Tambah Data Buku</title>
</head>
<body>
	<h3>Form Tambah Data Buku</h3>
	<form method="post" action="" enctype="multipart/form-data">
		<ul>
			<li>
				Masukkan Judul Buku :  <br>
				<input type="text" name="JudulBuku" id="JudulBuku"required>
			</li>
			<li>
				Pengarang :  <br>
				<input type="text" name="Pengarang" id="Pengarang" required>
			</li>
			<li>
				Penerbit :  <br>
				<input type="text" name="Penerbit" id="Penerbit" required>
			</li>
			<li>
				Tahun Terbit :  <br>
				<input type="text" name="TahunTerbit" id="TahunTerbit" required> <br>
			</li>
			<li>
				Harga :  <br>
				<input type="text" name="Harga" id="Harga" required> <br>
			</li>
			<li>
				Gambar :  <br>
				<input type="file" name="Gambar" id="Gambar" > <br>
			</li>	
			<li>
				<button type="submit" name="tambah">Kirim</button>
			</li>
		</ul>
	</form>
</body>
</html>